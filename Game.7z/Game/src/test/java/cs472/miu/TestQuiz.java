package cs472.miu;

import org.junit.Test;

import static org.junit.Assert.*;

public class TestQuiz {
    private Quiz quizUnderTest = new Quiz();

    @Test
    public void getNumCorrect() {
        assertEquals(0, quizUnderTest.getNumCorrect());

        quizUnderTest.scoreAnswer(); //score and index initially zero, increments the score and the current question number
        assertEquals(1, quizUnderTest.getNumCorrect());
        assertEquals(1, quizUnderTest.getCurrQIndex());
    }

    @Test
    public void isCorrect() {
        assertTrue("First question answer should be '9'", quizUnderTest.isCorrect("9"));
    }

    @Test
    public void scoreAnswer() {
        assertEquals(5, quizUnderTest.getNumQuestions());
    }


}