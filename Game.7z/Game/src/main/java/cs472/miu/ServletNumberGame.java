package cs472.miu;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/game")
public class ServletNumberGame extends HttpServlet {

    private void genQuizPage(Quiz sessQuiz, PrintWriter out, String currQuestn, boolean error, String answer) {

        out.print("<html>");
        out.print("<head>");
        out.print("	<title>NumberQuiz</title>");
        out.print("</head>");
        out.print("<body>");
        out.print("	<form method='post'>");
        out.print("<h3>Have fun with NumberQuiz!</h3>");
        out.print("<p>Your current score is: ");
        out.print(sessQuiz.getNumCorrect() + "</br></br>");
        out.print("<p>Guess the next number in the sequence! </p>");
        out.print("[" + currQuestn + "<font style='color:red'><b> ? </b></font>]</p>");

        out.print("<p>Your answer:<input type='text' name='txtAnswer' value='' /></p> ");

        if (error && (answer != null)) {    //REFACTOR?-- assumes answer null only when first open page

            out.print("<p style='color:red'>Your last answer was not correct! Please try again</p> ");
        }

        out.print("<p><input type='submit' name='btnNext' value='Next' /> ");
        out.print("<input type='submit' name='btnRestart' value='Restart' /></p> ");

        out.print("</form>");
        out.print("</body></html>");
    }

    private void genQuizOverPage(PrintWriter out) {
        out.print("<html> ");
        out.print("<head >");
        out.print("<title>Quiz is over</title> ");
        out.print("</head> ");
        out.print("<body> ");
        out.print("<p style='color:red'>Quiz is over!</p>");
        out.print("<form method='post'><input type='submit' name='btnStartAgain' value='Start Again!' /></form>");
        out.print("</body></html> ");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


        HttpSession session = request.getSession();
        Quiz quiz = (Quiz) session.getAttribute("Quiz");

        PrintWriter out = response.getWriter();

        if((request.getParameter("btnRestart") != null)||(request.getParameter("btnStartAgain") != null)) {
            session.invalidate();
            doGet(request, response);
        }

        if (request.getParameter("btnNext") != null) {
            if (quiz.getNumCorrect() == quiz.getNumQuestions() - 1) {//successful guess score
                genQuizOverPage(out);
            } else {
                String answer = request.getParameter("txtAnswer");
                boolean correct = quiz.isCorrect(answer);
                if (correct) {
                    quiz.scoreAnswer();
                }
                genQuizPage(quiz, out, quiz.getCurrentQuestion(), !correct, answer);
            }
        }
     }


    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        Quiz quiz = new Quiz();
        HttpSession session = request.getSession();
        session.setAttribute("Quiz", quiz);

        String currQuestion = quiz.getCurrentQuestion();
        genQuizPage(quiz, response.getWriter(), currQuestion, false, null);
    }
}
