package cs472.miu;

public class Question {
    String qnumber;
    String answer;

    public Question(String qnumber, String answer) {
        this.qnumber = qnumber;
        this.answer = answer;
    }

    public String getQuestion() {
        return qnumber;
    }

    public String getAnswer() {
        return answer;
    }

}
